// Optional real-data connector. Set RSS_FEEDS to a comma-separated list of
// trusted RSS URLs. It intentionally has no embedded keys or vendor lock-in.
async function fetchRssFeeds() {
  const feeds = (process.env.RSS_FEEDS || "").split(",").map((url) => url.trim()).filter(Boolean);
  const results = await Promise.allSettled(feeds.map(async (url) => {
    const response = await fetch(url, { headers: { "User-Agent": "PULSE-intelligence-prototype/1.0" } });
    if (!response.ok) throw new Error(`RSS request failed: ${response.status}`);
    const xml = await response.text();
    return [...xml.matchAll(/<item>[\s\S]*?<title><!\[CDATA\[(.*?)\]\]><\/title>[\s\S]*?<link>(.*?)<\/link>[\s\S]*?<pubDate>(.*?)<\/pubDate>[\s\S]*?<\/item>/g)].map((match) => ({ title: match[1], url: match[2], publishedAt: match[3], platform: "rss" }));
  }));
  return results.flatMap((result) => result.status === "fulfilled" ? result.value : []);
}
module.exports = { fetchRssFeeds };
