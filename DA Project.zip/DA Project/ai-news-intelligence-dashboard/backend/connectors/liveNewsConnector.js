const TOPIC_RULES = {
  "AI & Technology": /\b(ai|artificial intelligence|openai|chatgpt|machine learning|chip|semiconductor|quantum)\b/i,
  "Cybersecurity": /\b(cyber|hack|breach|ransomware|security)\b/i,
  "Climate & Energy": /\b(climate|weather|wildfire|energy|solar|renewable|oil)\b/i,
  "Business & Markets": /\b(market|stock|economy|inflation|interest rate|trade|crypto)\b/i,
  "Politics & Policy": /\b(election|government|policy|court|president|regulation)\b/i,
  "Science & Health": /\b(health|disease|vaccine|space|nasa|science)\b/i,
};

function decode(value = "") { return value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/<[^>]+>/g, "").trim(); }
function text(tag, xml) { const match = xml.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, "i")); return match ? decode(match[1]) : ""; }
function topicFor(headline) { return Object.entries(TOPIC_RULES).find(([, rule]) => rule.test(headline))?.[0] || "World News"; }
function sentimentFor(textValue) { const positive = /\b(gain|growth|breakthrough|win|success|improve|launch|agreement|record)\b/gi; const negative = /\b(crisis|fall|war|death|risk|breach|attack|failure|loss|fear|warning)\b/gi; const p = (textValue.match(positive) || []).length; const n = (textValue.match(negative) || []).length; return Math.max(-1, Math.min(1, (p - n) / Math.max(2, p + n))); }

async function googleNews(query = "world news", forcedTopic) {
  const response = await fetch(`https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-US&gl=US&ceid=US:en`, { headers: { "User-Agent": "PULSE-News-Intelligence/1.0" } });
  if (!response.ok) throw new Error(`Google News RSS: ${response.status}`);
  const xml = await response.text();
  return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 25).map((match, index) => {
    const item = match[1], title = text("title", item), source = text("source", item) || "Google News";
    return { id: `g-${Buffer.from(`${title}-${text("pubDate", item)}`).toString("base64url")}`, headline: title, url: text("link", item), source, sourceType: "wire", platform: "Google News RSS", timestamp: new Date(text("pubDate", item) || Date.now()).toISOString(), topic: forcedTopic || topicFor(title), sentiment: sentimentFor(title), engagement: 30 - index };
  }).filter((item) => item.headline);
}

async function hackerNews() {
  const response = await fetch("https://hn.algolia.com/api/v1/search_by_date?tags=story&hitsPerPage=20", { headers: { "User-Agent": "PULSE-News-Intelligence/1.0" } });
  if (!response.ok) throw new Error(`Hacker News: ${response.status}`);
  const json = await response.json();
  return json.hits.filter((hit) => hit.title).map((hit) => ({ id: `hn-${hit.objectID}`, headline: hit.title, url: hit.url || `https://news.ycombinator.com/item?id=${hit.objectID}`, source: "Hacker News", sourceType: "social", platform: "Hacker News", timestamp: hit.created_at, topic: topicFor(hit.title), sentiment: sentimentFor(hit.title), engagement: hit.points || 0 }));
}

async function reddit() {
  const response = await fetch("https://www.reddit.com/r/worldnews+technology+science/hot.json?limit=25", { headers: { "User-Agent": "PULSE-News-Intelligence/1.0 (educational dashboard)" } });
  if (!response.ok) throw new Error(`Reddit: ${response.status}`);
  const json = await response.json();
  return (json.data?.children || []).map(({ data }) => ({ id: `rd-${data.id}`, headline: data.title, url: `https://www.reddit.com${data.permalink}`, source: `r/${data.subreddit}`, sourceType: "social", platform: "Reddit", timestamp: new Date(data.created_utc * 1000).toISOString(), topic: topicFor(data.title), sentiment: sentimentFor(data.title), engagement: data.score || 0 }));
}

async function fetchLiveItems() {
  // Distinct live feeds give the dashboard a broad, meaningful topic set
  // instead of collapsing all headlines into a handful of generic buckets.
  const feeds = [
    ["artificial intelligence", "Artificial Intelligence"], ["cybersecurity", "Cybersecurity"],
    ["global politics", "Global Politics"], ["business markets economy", "Business & Markets"],
    ["climate change energy", "Climate & Energy"], ["health science", "Health & Science"],
    ["space exploration", "Space & Innovation"], ["sports news", "Sports"],
    ["entertainment news", "Entertainment"], ["India news", "India"], ["world news", "World News"]
  ];
  const jobs = [...feeds.map(([query, topic]) => googleNews(query, topic)), hackerNews(), reddit()];
  const settled = await Promise.allSettled(jobs);
  const errors = settled.filter((result) => result.status === "rejected").map((result) => result.reason.message);
  const items = settled.flatMap((result) => result.status === "fulfilled" ? result.value : []);
  return { items: [...new Map(items.map((item) => [item.id, item])).values()], errors, sourcesChecked: jobs.length };
}
module.exports = { fetchLiveItems, googleNews, topicFor, sentimentFor };
