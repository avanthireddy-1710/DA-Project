// In a real system this file would be replaced by connectors to
// Twitter/X, Reddit, RSS feeds, NewsAPI, etc. For this demo we
// generate realistic-looking data so the whole pipeline (backend
// aggregation -> REST -> WebSocket -> frontend charts) can be seen
// working end to end.

const TOPICS = [
  "AI Regulation", "Elections 2026", "Climate Summit", "Chip Shortage",
  "Space Launch", "Interest Rates", "Cybersecurity Breach", "Olympics",
  "Streaming Wars", "EV Market", "Quantum Computing", "Public Health Alert",
  "Trade Tariffs", "Labor Strikes", "Wildfire Season", "Crypto Regulation",
  "Supreme Court Ruling", "Global Supply Chain", "Renewable Energy", "Gaming Industry"
];

const SOURCES = [
  { name: "Reuters", type: "wire" },
  { name: "Associated Press", type: "wire" },
  { name: "Bloomberg", type: "wire" },
  { name: "X / Twitter", type: "social" },
  { name: "Reddit", type: "social" },
  { name: "BBC News", type: "broadcast" },
  { name: "CNN", type: "broadcast" },
  { name: "TechCrunch", type: "blog" },
  { name: "The Verge", type: "blog" },
  { name: "Al Jazeera", type: "broadcast" },
  { name: "Hacker News", type: "social" },
  { name: "NYTimes", type: "wire" },
];

const COUNTRIES = [
  { code: "US", name: "United States", lat: 39.8, lng: -98.5 },
  { code: "IN", name: "India", lat: 22.0, lng: 79.0 },
  { code: "GB", name: "United Kingdom", lat: 54.0, lng: -2.0 },
  { code: "DE", name: "Germany", lat: 51.0, lng: 10.0 },
  { code: "BR", name: "Brazil", lat: -10.0, lng: -55.0 },
  { code: "JP", name: "Japan", lat: 36.0, lng: 138.0 },
  { code: "AU", name: "Australia", lat: -25.0, lng: 133.0 },
  { code: "ZA", name: "South Africa", lat: -29.0, lng: 24.0 },
  { code: "CA", name: "Canada", lat: 56.0, lng: -106.0 },
  { code: "AE", name: "UAE", lat: 24.0, lng: 54.0 },
];

const HEADLINE_TEMPLATES = [
  "{topic}: what we know so far",
  "Breaking: major development in {topic}",
  "{topic} sparks global reaction online",
  "Explainer: why {topic} matters right now",
  "Live updates: {topic} continues to unfold",
  "Analysts weigh in on {topic}",
  "{topic} trends worldwide as story develops",
  "New report reshapes {topic} narrative",
];

// Reaction scale for a single clicked story. Mirrors the 5-point
// scale: hate it / dislike it / neutral / good / love it.
const EMOJI_SCALE = [
  { emoji: "🤢", label: "Public hates this", max: -0.55 },
  { emoji: "😬", label: "Public dislikes this", max: -0.15 },
  { emoji: "🙂", label: "Public feels neutral", max: 0.15 },
  { emoji: "😁", label: "Public likes this", max: 0.55 },
  { emoji: "😊", label: "Public loves this", max: Infinity },
];

const RELATION_TAGS = ["Same topic", "Same region", "Shared keyword", "Related development"];

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

function clampRange(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function makeHeadline(topic) {
  return pick(HEADLINE_TEMPLATES).replace("{topic}", topic);
}

function emojiForSentiment(sentiment) {
  return EMOJI_SCALE.find((e) => sentiment <= e.max) || EMOJI_SCALE[EMOJI_SCALE.length - 1];
}

// Builds all the "click into a story" analytics: per-country like/dislike
// split + virality chance, the sources actually carrying this story, a
// handful of relatable stories, and the single emoji summarizing global
// reaction. Everything is derived from the story's own topic/sentiment so
// it stays internally consistent (a very negative story skews red/dislike
// across most countries, etc.) while still varying country to country.
function buildStoryAnalytics(topic, mainSentiment) {
  const countries = COUNTRIES.map((c) => {
    const sentiment = clampRange(mainSentiment + randomBetween(-0.5, 0.5), -1, 1);
    const likePercent = Math.round(clampRange(50 + sentiment * 50, 2, 98));
    const dislikePercent = 100 - likePercent;
    const viralChance = Math.round(
      clampRange(40 + Math.abs(sentiment) * 40 + randomBetween(-15, 15), 5, 99)
    );
    return {
      code: c.code,
      name: c.name,
      lat: c.lat,
      lng: c.lng,
      sentiment: +sentiment.toFixed(2),
      likePercent,
      dislikePercent,
      viralChance,
      mentions: Math.floor(randomBetween(100, 9000)),
    };
  });

  const viralityScore = Math.round(
    countries.reduce((sum, c) => sum + c.viralChance, 0) / countries.length
  );

  const sourceCount = Math.floor(randomBetween(5, SOURCES.length + 1));
  const sources = [...SOURCES]
    .sort(() => Math.random() - 0.5)
    .slice(0, sourceCount)
    .map((s) => ({ ...s, articles: Math.floor(randomBetween(10, 400)) }))
    .sort((a, b) => b.articles - a.articles);

  const relatable = Array.from({ length: 5 }).map((_, i) => {
    const relTopic = Math.random() < 0.6 ? topic : pick(TOPICS);
    return {
      id: `rel-${topic}-${i}-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      headline: makeHeadline(relTopic),
      topic: relTopic,
      source: pick(SOURCES).name,
      country: pick(COUNTRIES).code,
      relation: pick(RELATION_TAGS),
    };
  });

  const { emoji, label } = emojiForSentiment(mainSentiment);

  return { countries, sources, relatable, emoji, emojiLabel: label, viralityScore };
}

module.exports = {
  TOPICS,
  SOURCES,
  COUNTRIES,
  pick,
  randomBetween,
  makeHeadline,
  emojiForSentiment,
  buildStoryAnalytics,
};
