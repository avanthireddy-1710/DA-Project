// Lightweight, dependency-free NLP enrichment. Replace these heuristics with a
// hosted classifier or local transformer without changing the API contract.
const RISK_TERMS = ["breach", "alert", "shortage", "wildfire", "strikes", "tariffs", "crisis"];
const ENTITY_WORDS = ["AI", "US", "India", "EU", "NASA", "Olympics", "Supreme Court", "Reuters"];

function keywords(text) {
  const stop = new Set(["the", "and", "for", "with", "what", "this", "that", "from", "into", "so", "far", "new", "why", "now"]);
  return [...new Set((text.match(/[A-Za-z][A-Za-z-]{2,}/g) || []).filter((x) => !stop.has(x.toLowerCase())).map((x) => x.toLowerCase()))].slice(0, 6);
}

function enrichStory(story) {
  const text = `${story.headline} ${story.topic}`;
  const riskHits = RISK_TERMS.filter((word) => text.toLowerCase().includes(word));
  const anomalyScore = Math.min(99, Math.round(story.velocity * 0.22 + story.viralityScore * 0.48 + Math.abs(story.sentiment) * 18));
  return {
    ...story,
    summary: `${story.topic} is accelerating across ${story.sources.length} sources with ${story.velocity}% hourly growth. Audience response is ${story.sentiment > .15 ? "predominantly positive" : story.sentiment < -.15 ? "predominantly negative" : "mixed"}.`,
    keywords: keywords(text),
    entities: ENTITY_WORDS.filter((entity) => text.includes(entity)),
    riskLevel: riskHits.length >= 2 || anomalyScore > 82 ? "high" : riskHits.length || anomalyScore > 60 ? "medium" : "low",
    anomalyScore,
    credibility: Math.round(Math.min(98, 54 + story.sources.filter((s) => s.type === "wire").length * 7 + story.sources.length * 2)),
  };
}

module.exports = { enrichStory };
