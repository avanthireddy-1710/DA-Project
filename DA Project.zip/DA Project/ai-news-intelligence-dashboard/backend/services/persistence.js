const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "..", "data", "intelligence-history.json");
function readHistory() { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return []; } }
function appendHistory(point) {
  const history = readHistory();
  history.push(point);
  fs.writeFileSync(file, JSON.stringify(history.slice(-288), null, 2)); // 24 hours at 5-minute aggregation
}
module.exports = { readHistory, appendHistory };
