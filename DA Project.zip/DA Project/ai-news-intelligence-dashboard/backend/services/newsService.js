const { COUNTRIES, buildStoryAnalytics } = require("../data/mockNews");
const { fetchLiveItems, googleNews } = require("../connectors/liveNewsConnector");
const { enrichStory } = require("./analytics");
const { readHistory, appendHistory } = require("./persistence");
let alerts = [];
const state = { items: [], errors: [], sourcesChecked: 0, lastRefresh: null, previous: new Map() };
const countryFor = (text) => COUNTRIES.find((c) => new RegExp(`\\b${c.name.replace("United States", "United States|US|U\\.S\\.")}\\b`, "i").test(text)) || COUNTRIES[0];
const typeFor = (source) => source === "Hacker News" || source.startsWith("r/") ? "social" : "wire";

async function refreshLiveFeed() { const result = await fetchLiveItems(); state.items = result.items; state.errors = result.errors; state.sourcesChecked = result.sourcesChecked; state.lastRefresh = new Date().toISOString(); return getSnapshot(); }
function getSnapshot() {
  const items = state.items, totalMentions = items.reduce((n, x) => n + Math.max(1, x.engagement || 1), 0), groups = new Map();
  items.forEach((x) => { const g = groups.get(x.topic) || { topic:x.topic, mentions:0, sentimentSum:0, count:0 }; g.mentions += Math.max(1,x.engagement||1); g.sentimentSum += x.sentiment; g.count++; groups.set(x.topic,g); });
  // Trending = the top individual live headlines (ranked by engagement), not category buckets.
  const trending = items.slice().sort((a,b)=>Math.max(1,b.engagement||1)-Math.max(1,a.engagement||1)).slice(0,10).map((x)=>{
    const mentions=Math.max(1,x.engagement||1);
    const prior=state.previous.get(x.id);
    const velocity=prior!==undefined?((mentions-prior)/Math.max(1,prior))*100:Math.min(500,Math.max(10,Math.round(mentions*1.5)));
    return { topic:x.headline, id:x.id, url:x.url, source:x.source, category:x.topic, timestamp:x.timestamp, mentions, sentiment:+x.sentiment.toFixed(2), velocity:+velocity.toFixed(1), share:totalMentions?+((mentions/totalMentions)*100).toFixed(1):0 };
  });
  state.previous = new Map(items.map((x)=>[x.id,Math.max(1,x.engagement||1)]));
  const sources = [...items.reduce((map,x)=>{const s=map.get(x.source)||{name:x.source,type:typeFor(x.source),articles:0};s.articles++;map.set(x.source,s);return map},new Map()).values()].sort((a,b)=>b.articles-a.articles);
  const geo = COUNTRIES.map((c)=>{const list=items.filter((x)=>countryFor(x.headline).code===c.code);return {...c,mentions:list.reduce((n,x)=>n+Math.max(1,x.engagement),0),sentiment:list.length?+(list.reduce((n,x)=>n+x.sentiment,0)/list.length).toFixed(2):0}}).sort((a,b)=>b.mentions-a.mentions);
  const emerging = items.slice().sort((a,b)=>new Date(b.timestamp)-new Date(a.timestamp)).slice(0,12).map((x)=>{ const c=countryFor(x.headline); const velocity=Math.min(500, Math.max(10, Math.round((x.engagement||1)*1.5))); return enrichStory({...x,country:c.code,velocity,...buildStoryAnalytics(x.topic,x.sentiment)}); });
  const buckets=items.reduce((a,x)=>{if(x.sentiment>.15)a.positive++;else if(x.sentiment<-.15)a.negative++;else a.neutral++;return a},{positive:0,neutral:0,negative:0}), avg=items.length?items.reduce((n,x)=>n+x.sentiment,0)/items.length:0, history=readHistory();
  const snapshot={generatedAt:new Date().toISOString(),totalMentions,avgSentiment:+avg.toFixed(3),trending,sentimentBuckets:buckets,sources,geo,emerging,history:history.slice(-24),liveStatus:{isLive:true,lastRefresh:state.lastRefresh,sourcesChecked:state.sourcesChecked,errors:state.errors},alertMatches:alerts.filter((a)=>trending.some((t)=>t.topic===a.topic&&t.velocity>=a.threshold))};
  const latest=history.at(-1); if(state.lastRefresh&&(!latest||Date.now()-new Date(latest.timestamp)>300000))appendHistory({timestamp:snapshot.generatedAt,mentions:totalMentions,sentiment:snapshot.avgSentiment,emerging:emerging.length}); return snapshot;
}
function getStory(id){return getSnapshot().emerging.find((s)=>String(s.id)===String(id))||null} function listAlerts(){return alerts} function addAlert({topic,threshold=50,channel="dashboard"}){if(!topic)throw new Error("topic is required");const a={id:`${Date.now()}-${Math.random().toString(16).slice(2)}`,topic,threshold:Number(threshold),channel,createdAt:new Date().toISOString()};alerts.push(a);return a} function removeAlert(id){alerts=alerts.filter((a)=>a.id!==id)}
async function searchLive(query) { if (!query || query.trim().length < 2) return []; const items = await googleNews(query.trim(), `Search: ${query.trim()}`); return items.map((x)=>{const c=countryFor(x.headline);return enrichStory({...x,country:c.code,velocity:Math.min(500,Math.max(10,Math.round((x.engagement||1)*1.5))),...buildStoryAnalytics(x.topic,x.sentiment)})}); }
module.exports={refreshLiveFeed,getSnapshot,getStory,listAlerts,addAlert,removeAlert,searchLive};
