const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

const newsRoutes = require("./routes/news");
const { refreshLiveFeed, getSnapshot } = require("./services/newsService");

const PORT = process.env.PORT || 4000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "http://localhost:5173";

const app = express();
app.use(cors({ origin: CLIENT_ORIGIN }));
app.use(express.json());

app.get("/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));
app.use("/api/news", newsRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: CLIENT_ORIGIN, methods: ["GET", "POST"] },
});

io.on("connection", (socket) => {
  console.log(`[socket] client connected: ${socket.id}`);
  // Send current state immediately on connect
  socket.emit("snapshot", getSnapshot());

  socket.on("disconnect", () => {
    console.log(`[socket] client disconnected: ${socket.id}`);
  });
});

// Pull public real-world sources every five minutes and broadcast the result.
async function refreshAndBroadcast() {
  try { io.emit("snapshot", await refreshLiveFeed()); }
  catch (error) { console.error(`[ingestion] ${error.message}`); }
}
refreshAndBroadcast();
setInterval(refreshAndBroadcast, 5 * 60 * 1000);

server.listen(PORT, () => {
  console.log(`AI News Intelligence backend running on http://localhost:${PORT}`);
  console.log(`Allowing client origin: ${CLIENT_ORIGIN}`);
});
