const express = require("express");
const { getSnapshot, getStory, listAlerts, addAlert, removeAlert, searchLive } = require("../services/newsService");

const router = express.Router();

// GET /api/news/snapshot -> everything the dashboard needs on first load
router.get("/snapshot", (req, res) => {
  res.json(getSnapshot());
});

// GET /api/news/story/:id -> full detail + per-country reaction analytics
// for a single story clicked from the breaking-news ticker
router.get("/story/:id", (req, res) => {
  const story = getStory(req.params.id);
  if (!story) return res.status(404).json({ error: "Story not found" });
  res.json(story);
});

// GET /api/news/trending
router.get("/trending", (req, res) => {
  res.json(getSnapshot().trending);
});

// GET /api/news/sentiment
router.get("/sentiment", (req, res) => {
  const snap = getSnapshot();
  res.json({ avgSentiment: snap.avgSentiment, buckets: snap.sentimentBuckets });
});

// GET /api/news/geo
router.get("/geo", (req, res) => {
  res.json(getSnapshot().geo);
});

// GET /api/news/sources
router.get("/sources", (req, res) => {
  res.json(getSnapshot().sources);
});

// GET /api/news/emerging
router.get("/emerging", (req, res) => {
  res.json(getSnapshot().emerging);
});
router.get("/search", async (req, res) => {
  try { res.json(await searchLive(req.query.q)); }
  catch (error) { res.status(502).json({ error: `Live search unavailable: ${error.message}` }); }
});

// Analyst alert rules. Webhook/email integrations can subscribe to this same
// service later; the dashboard currently consumes it in-app.
router.get("/alerts", (req, res) => res.json(listAlerts()));
router.post("/alerts", (req, res) => {
  try { res.status(201).json(addAlert(req.body)); }
  catch (error) { res.status(400).json({ error: error.message }); }
});
router.delete("/alerts/:id", (req, res) => { removeAlert(req.params.id); res.status(204).end(); });

module.exports = router;
