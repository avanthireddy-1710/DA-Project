export default function GeoDistribution({ geo }) {
  const max = Math.max(...geo.map((g) => g.mentions), 1);

  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Geographic Distribution</h2>
        <span className="text-xs text-muted font-mono">mentions by region</span>
      </div>

      <div className="space-y-3">
        {geo.map((g) => (
          <div key={g.code} className="flex items-center gap-3">
            <span className="font-mono text-[11px] text-muted w-8 shrink-0">{g.code}</span>
            <span className="text-sm text-fog w-32 truncate shrink-0">{g.name}</span>
            <div className="flex-1 h-2 bg-panel2 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-signal/80"
                style={{ width: `${(g.mentions / max) * 100}%` }}
              />
            </div>
            <span className="font-mono text-xs text-fog w-14 text-right shrink-0">
              {g.mentions.toLocaleString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
