export default function RelatableStories({ stories }) {
  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Relatable Stories</h2>
        <span className="text-[11px] font-mono text-muted">related coverage</span>
      </div>

      <ul className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
        {(!stories || stories.length === 0) && (
          <li className="text-sm text-muted">No related stories found.</li>
        )}
        {stories?.map((s) => (
          <li key={s.id} className="border-b border-line pb-3 last:border-0 last:pb-0">
            <div className="flex items-center gap-2 mb-1 text-[11px] font-mono text-muted">
              <span>{s.source}</span>
              <span>·</span>
              <span>{s.country}</span>
              <span className="ml-auto text-signal">{s.relation}</span>
            </div>
            <p className="text-sm text-fog leading-snug">{s.headline}</p>
            <span className="inline-block mt-1 text-[10px] uppercase tracking-wide text-muted bg-panel2 px-2 py-0.5 rounded">
              {s.topic}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
