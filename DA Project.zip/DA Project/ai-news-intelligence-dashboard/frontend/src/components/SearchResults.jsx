function timeAgo(iso) {
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  return h < 24 ? `${h}h ago` : `${Math.floor(h / 24)}d ago`;
}

export default function SearchResults({ query, results, searching, onSelect }) {
  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">
          Search Results · “{query.trim()}”
        </h2>
        <span className="text-xs text-muted font-mono">
          {searching ? "searching…" : `${results.length} live results`}
        </span>
      </div>

      <ol className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
        {!searching && results.length === 0 && (
          <li className="text-sm text-muted">No results found for this search.</li>
        )}
        {results.map((s, i) => (
          <li key={s.id || i} className="border-b border-line pb-3 last:border-0 last:pb-0">
            <div className="flex items-center gap-2 mb-1 text-[11px] font-mono text-muted">
              <span className="w-5 shrink-0">{String(i + 1).padStart(2, "0")}</span>
              {s.source && <span>{s.source}</span>}
              {s.country && <><span>·</span><span>{s.country}</span></>}
              {s.timestamp && <span className="ml-auto">{timeAgo(s.timestamp)}</span>}
            </div>
            <button
              onClick={() => onSelect?.(s)}
              className="text-left text-sm text-fog leading-snug hover:text-signal pl-7"
            >
              {s.headline}
            </button>
            <div className="flex items-center gap-2 pl-7 mt-1 text-[10px] font-mono text-muted">
              {s.topic && <span className="rounded bg-panel2 px-1.5 py-0.5 uppercase">{s.topic}</span>}
              {s.url && (
                <a href={s.url} target="_blank" rel="noreferrer" className="text-signal hover:underline shrink-0">
                  read ↗
                </a>
              )}
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
