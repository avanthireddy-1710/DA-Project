import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const COLORS = { positive: "#3FD8C2", neutral: "#7C8798", negative: "#FF6B6B" };

export default function SentimentChart({ avgSentiment, buckets }) {
  const data = [
    { name: "Positive", key: "positive", value: buckets.positive },
    { name: "Neutral", key: "neutral", value: buckets.neutral },
    { name: "Negative", key: "negative", value: buckets.negative },
  ];

  const label =
    avgSentiment > 0.15 ? "Net Positive" : avgSentiment < -0.15 ? "Net Negative" : "Net Neutral";
  const labelColor =
    avgSentiment > 0.15 ? "text-pulse" : avgSentiment < -0.15 ? "text-alert" : "text-muted";

  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Global Sentiment</h2>
      </div>

      <div className="relative flex-1 min-h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius="65%"
              outerRadius="90%"
              paddingAngle={3}
              stroke="none"
            >
              {data.map((d) => (
                <Cell key={d.key} fill={COLORS[d.key]} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{ background: "#171E2C", border: "1px solid #232B3A", borderRadius: 8 }}
              itemStyle={{ color: "#C4CCDA", fontSize: 12 }}
            />
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="font-mono text-xl text-fog">{avgSentiment >= 0 ? "+" : ""}{avgSentiment.toFixed(2)}</span>
          <span className={`text-xs font-medium ${labelColor}`}>{label}</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mt-4 text-center">
        {data.map((d) => (
          <div key={d.key}>
            <div className="font-mono text-sm text-fog">{d.value}</div>
            <div className="text-[10px] uppercase tracking-wide" style={{ color: COLORS[d.key] }}>
              {d.name}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
