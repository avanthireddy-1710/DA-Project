export default function CountryReactions({ countries }) {
  const sorted = [...countries].sort((a, b) => b.likePercent - a.likePercent);

  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Country Reactions</h2>
        <span className="text-xs text-muted font-mono">like vs dislike · viral chance</span>
      </div>

      <ol className="space-y-3">
        {sorted.map((c) => (
          <li key={c.code} className="group">
            <div className="flex items-baseline justify-between gap-3 mb-1">
              <div className="flex items-baseline gap-2 min-w-0">
                <span className="font-mono text-xs text-muted w-8 shrink-0">{c.code}</span>
                <span className="text-sm text-fog truncate">{c.name}</span>
              </div>
              <div className="flex items-baseline gap-3 shrink-0 font-mono text-xs">
                <span className="text-pulse">▲ {c.likePercent}%</span>
                <span className="text-alert">▼ {c.dislikePercent}%</span>
                <span className="text-muted">viral {c.viralChance}%</span>
              </div>
            </div>
            <div className="h-1.5 bg-panel2 rounded-full overflow-hidden flex">
              <div className="h-full bg-pulse" style={{ width: `${c.likePercent}%` }} />
              <div className="h-full bg-alert" style={{ width: `${c.dislikePercent}%` }} />
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
