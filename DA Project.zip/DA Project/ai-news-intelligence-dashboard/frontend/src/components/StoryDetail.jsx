import CountryReactions from "./CountryReactions";
import ReactionEmoji from "./ReactionEmoji";
import SourceFrequency from "./SourceFrequency";
import RelatableStories from "./RelatableStories";
import GeoDistribution from "./GeoDistribution";

function timeAgo(iso) {
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

export default function StoryDetail({ story, onBack }) {
  // GeoDistribution just needs {code, name, mentions}, so the same
  // per-country analytics that drive the reaction bars can feed the map
  // below without any extra backend calls.
  const geo = story.countries.map((c) => ({ code: c.code, name: c.name, mentions: c.mentions }));

  return (
    <div>
      <button
        onClick={onBack}
        className="mb-4 flex items-center gap-2 text-xs font-mono text-muted hover:text-fog transition-colors"
      >
        ← Back to dashboard
      </button>

      <div className="bg-panel border border-line rounded-xl p-5 mb-5">
        <div className="flex items-center gap-2 mb-2 text-[11px] font-mono text-muted flex-wrap">
          <span className="text-signal">▲ {story.velocity}%/hr</span>
          <span>·</span>
          <span>{story.source}</span>
          <span>·</span>
          <span>{story.country}</span>
          <span>·</span>
          <span>{timeAgo(story.timestamp)}</span>
          <span className="ml-auto">
            Virality score: <span className="text-fog">{story.viralityScore}%</span>
          </span>
        </div>
        <h1 className="font-display text-lg text-fog leading-snug">{story.headline}</h1>
        <span className="inline-block mt-2 text-[10px] uppercase tracking-wide text-muted bg-panel2 px-2 py-0.5 rounded">
          {story.topic}
        </span>
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3 text-xs">
          <div className="rounded-lg bg-panel2 p-3"><span className="text-muted">AI brief</span><p className="mt-1 leading-relaxed text-fog">{story.summary || "Summary is being generated."}</p></div>
          <div className="rounded-lg bg-panel2 p-3"><span className="text-muted">Signal quality</span><p className="mt-1 text-fog">Anomaly <b className="text-signal">{story.anomalyScore ?? "—"}/99</b> · Credibility <b className="text-pulse">{story.credibility ?? "—"}/100</b></p><p className="mt-2 text-muted">Risk: <span className={story.riskLevel === "high" ? "text-alert" : "text-signal"}>{story.riskLevel || "pending"}</span></p></div>
          <div className="rounded-lg bg-panel2 p-3"><span className="text-muted">Entities & keywords</span><p className="mt-1 text-fog">{[...(story.entities || []), ...(story.keywords || [])].join(" · ") || "Extracting entities…"}</p></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2">
          <CountryReactions countries={story.countries} />
        </div>
        <ReactionEmoji emoji={story.emoji} label={story.emojiLabel} sentiment={story.sentiment} />

        <div className="lg:col-span-2">
          <SourceFrequency sources={story.sources} />
        </div>
        <RelatableStories stories={story.relatable} />

        <div className="lg:col-span-3">
          <GeoDistribution geo={geo} />
        </div>
      </div>
    </div>
  );
}
