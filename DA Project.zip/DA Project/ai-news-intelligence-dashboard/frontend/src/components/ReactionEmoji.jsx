export default function ReactionEmoji({ emoji, label, sentiment }) {
  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Global Reaction</h2>
      </div>

      <div className="flex-1 min-h-[180px] flex flex-col items-center justify-center gap-3">
        <span style={{ fontSize: "72px", lineHeight: 1 }} role="img" aria-label={label}>
          {emoji}
        </span>
        <span className="text-sm font-medium text-fog text-center">{label}</span>
        <span className="font-mono text-xs text-muted">
          sentiment {sentiment >= 0 ? "+" : ""}
          {sentiment.toFixed(2)}
        </span>
      </div>
    </div>
  );
}
