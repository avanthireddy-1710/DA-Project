function timeAgo(iso) {
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}

export default function EmergingStories({ stories, onSelect }) {
  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Emerging Stories</h2>
        <span className="flex items-center gap-1.5 text-[11px] font-mono text-signal">
          <span className="w-1.5 h-1.5 rounded-full bg-signal live-dot" />
          LIVE
        </span>
      </div>

      <ul className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
        {stories.length === 0 && (
          <li className="text-sm text-muted">Waiting for spikes in coverage…</li>
        )}
        {stories.map((s) => (
          <li
            key={s.id}
            onClick={() => onSelect?.(s)}
            className={`border-b border-line pb-3 last:border-0 last:pb-0 ${
              onSelect ? "cursor-pointer hover:opacity-80 transition-opacity" : ""
            }`}
            title={onSelect ? "Click for full breakdown" : undefined}
          >
            <div className="flex items-center gap-2 mb-1 text-[11px] font-mono text-muted">
              <span className="text-signal">▲ {s.velocity}%/hr</span>
              <span>·</span>
              <span>{s.source}</span>
              <span>·</span>
              <span>{s.country}</span>
              <span className="ml-auto">{timeAgo(s.timestamp)}</span>
            </div>
            <p className="text-sm text-fog leading-snug">{s.headline}</p>
            <span className="inline-block mt-1 text-[10px] uppercase tracking-wide text-muted bg-panel2 px-2 py-0.5 rounded">
              {s.topic}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
