import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell } from "recharts";

const TYPE_COLORS = { wire: "#FFB020", social: "#3FD8C2", broadcast: "#7C8798", blog: "#FF6B6B" };

export default function SourceFrequency({ sources }) {
  const data = sources.slice(0, 8);

  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Source Frequency</h2>
        <div className="flex gap-3 text-[10px] font-mono">
          {Object.entries(TYPE_COLORS).map(([type, color]) => (
            <span key={type} className="flex items-center gap-1 text-muted">
              <span className="w-2 h-2 rounded-full inline-block" style={{ background: color }} />
              {type}
            </span>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={240}>
        <BarChart data={data} layout="vertical" margin={{ left: 0, right: 16, top: 0, bottom: 0 }}>
          <XAxis type="number" hide />
          <YAxis
            type="category"
            dataKey="name"
            width={100}
            tick={{ fill: "#C4CCDA", fontSize: 12 }}
            axisLine={{ stroke: "#232B3A" }}
            tickLine={false}
          />
          <Tooltip
            cursor={{ fill: "#171E2C" }}
            contentStyle={{ background: "#171E2C", border: "1px solid #232B3A", borderRadius: 8 }}
            itemStyle={{ color: "#C4CCDA", fontSize: 12 }}
          />
          <Bar dataKey="articles" radius={[0, 6, 6, 0]}>
            {data.map((s) => (
              <Cell key={s.name} fill={TYPE_COLORS[s.type] || "#7C8798"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
