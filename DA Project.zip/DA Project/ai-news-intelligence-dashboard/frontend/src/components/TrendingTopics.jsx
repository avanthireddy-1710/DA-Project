function sentimentColor(s) {
  if (s > 0.15) return "text-pulse";
  if (s < -0.15) return "text-alert";
  return "text-muted";
}

export default function TrendingTopics({ topics, watchlist = [], onWatch, onSelect }) {
  const max = Math.max(...topics.map((t) => t.mentions), 1);

  return (
    <div className="bg-panel border border-line rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-sm tracking-wide text-fog uppercase">Trending News</h2>
        <span className="text-xs text-muted font-mono">live · by engagement · ☆ watch</span>
      </div>

      <ol className="space-y-3">
        {topics.map((t, i) => (
          <li key={t.topic} className="group">
            <div className="flex items-baseline justify-between gap-3 mb-1">
              <div className="flex items-baseline gap-2 min-w-0">
                <span className="font-mono text-xs text-muted w-5 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                <button onClick={() => onSelect?.(t)} title={t.topic} className="text-left text-sm text-fog truncate hover:text-signal">{t.topic}</button>
                <button onClick={() => onWatch?.(t.topic)} className={`text-sm ${watchlist.includes(t.topic) ? "text-signal" : "text-muted hover:text-signal"}`} title="Add to alert watchlist">{watchlist.includes(t.topic) ? "★" : "☆"}</button>
              </div>
              <div className="flex items-baseline gap-2 shrink-0">
                <span className={`font-mono text-xs ${t.velocity >= 0 ? "text-pulse" : "text-alert"}`}>
                  {t.velocity >= 0 ? "▲" : "▼"} {Math.abs(Math.round(t.velocity))}%
                </span>
                <span className="font-mono text-xs text-fog">{t.mentions.toLocaleString()}</span>
              </div>
            </div>
            <div className="flex items-center gap-2 pl-7 mb-1 text-[10px] font-mono text-muted">
              {t.category && <span className="rounded bg-panel2 px-1.5 py-0.5">{t.category}</span>}
              {t.source && <span className="truncate">{t.source}</span>}
              {t.url && <a href={t.url} target="_blank" rel="noreferrer" className="text-signal hover:underline shrink-0">read ↗</a>}
            </div>
            <div className="h-1.5 bg-panel2 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full ${sentimentColor(t.sentiment).replace("text-", "bg-")}`}
                style={{ width: `${(t.mentions / max) * 100}%` }}
              />
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
