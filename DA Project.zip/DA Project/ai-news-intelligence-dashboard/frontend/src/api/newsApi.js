import { io } from "socket.io-client";

export const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:4000";

export async function fetchSnapshot() {
  const res = await fetch(`${API_BASE}/api/news/snapshot`);
  if (!res.ok) throw new Error(`Snapshot request failed: ${res.status}`);
  return res.json();
}

export async function fetchStory(id) {
  const res = await fetch(`${API_BASE}/api/news/story/${id}`);
  if (!res.ok) throw new Error(`Story request failed: ${res.status}`);
  return res.json();
}

export async function fetchAlerts() {
  const res = await fetch(`${API_BASE}/api/news/alerts`);
  if (!res.ok) throw new Error(`Alerts request failed: ${res.status}`);
  return res.json();
}

export async function createAlert(topic, threshold = 50) {
  const res = await fetch(`${API_BASE}/api/news/alerts`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ topic, threshold }) });
  if (!res.ok) throw new Error("Could not save alert");
  return res.json();
}

export async function deleteAlert(id) { await fetch(`${API_BASE}/api/news/alerts/${id}`, { method: "DELETE" }); }
export async function searchLiveNews(query) { const res = await fetch(`${API_BASE}/api/news/search?q=${encodeURIComponent(query)}`); if (!res.ok) throw new Error("Live search unavailable"); return res.json(); }
export async function runScenario(scenario) { const res = await fetch(`${API_BASE}/api/news/demo/${scenario}`, { method: "POST" }); if (!res.ok) throw new Error("Demo scenario failed"); return res.json(); }

export function connectSocket(onSnapshot) {
  const socket = io(API_BASE, { transports: ["websocket"] });
  socket.on("snapshot", onSnapshot);
  return socket;
}
