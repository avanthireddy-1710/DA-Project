import { useEffect, useRef, useState } from "react";
import { fetchSnapshot, fetchAlerts, createAlert, deleteAlert, searchLiveNews, connectSocket } from "./api/newsApi";
import TrendingTopics from "./components/TrendingTopics";
import SearchResults from "./components/SearchResults";
import SentimentChart from "./components/SentimentChart";
import GeoDistribution from "./components/GeoDistribution";
import SourceFrequency from "./components/SourceFrequency";
import EmergingStories from "./components/EmergingStories";
import StoryDetail from "./components/StoryDetail";
import IntelligenceBar from "./components/IntelligenceBar";
import ActivityTimeline from "./components/ActivityTimeline";
import GeoMap from "./components/GeoMap";
import TopicDetail from "./components/TopicDetail";

export default function App() {
  const [snapshot, setSnapshot] = useState(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState(null);
  // Full story object captured at click time (it carries its own
  // per-country reaction analytics, so the detail view doesn't depend on
  // the story still being present in the live-updating emerging list).
  const [selectedStory, setSelectedStory] = useState(null);
  const [query, setQuery] = useState("");
  const [sourceType, setSourceType] = useState("all");
  const [watchlist, setWatchlist] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [toast, setToast] = useState("");
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [user, setUser] = useState(() => localStorage.getItem("pulse-user") || "");
  const socketRef = useRef(null);

  useEffect(() => {
    let mounted = true;

    fetchSnapshot()
      .then((data) => mounted && setSnapshot(data))
      .catch((e) => mounted && setError(e.message));
    fetchAlerts().then((data) => {
      if (mounted) { setAlerts(data); setWatchlist(data.map((alert) => alert.topic)); }
    }).catch(() => {});

    const socket = connectSocket((data) => {
      setSnapshot(data);
      setConnected(true);
      setError(null);
    });
    socket.on("connect_error", () => setConnected(false));
    socket.on("disconnect", () => setConnected(false));
    socketRef.current = socket;

    return () => {
      mounted = false;
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) { setSearchResults([]); return; }
    const timer = setTimeout(async () => {
      try { setSearching(true); setSearchResults(await searchLiveNews(query)); }
      catch { setSearchResults([]); }
      finally { setSearching(false); }
    }, 450);
    return () => clearTimeout(timer);
  }, [query]);

  const searchActive = query.trim().length >= 2;
  const matchesSource = (story) =>
    sourceType === "all" || snapshot?.sources.find((s) => s.name === story.source)?.type === sourceType;
  // Search results replace the Trending panel; Emerging Stories stays independent.
  const filteredTopics = snapshot?.trending || [];
  const filteredSearchResults = searchResults.filter(matchesSource);
  const filteredStories = (snapshot?.emerging || []).filter(matchesSource);

  function exportBrief() {
    if (!snapshot) return;
    const rows = ["Topic,Mentions,Velocity,Sentiment", ...snapshot.trending.map((t) =>
      `"${t.topic}",${t.mentions},${Math.round(t.velocity)},${t.sentiment.toFixed(2)}`
    )];
    const url = URL.createObjectURL(new Blob([rows.join("\n")], { type: "text/csv" }));
    const link = document.createElement("a");
    link.href = url; link.download = "pulse-intelligence-brief.csv"; link.click();
    URL.revokeObjectURL(url);
    setToast("Intelligence brief exported as CSV");
    setTimeout(() => setToast(""), 2600);
  }
  function exportReport() {
    if (!snapshot) return;
    const body = `<h1>PULSE — Daily Intelligence Brief</h1><p>Generated ${new Date().toLocaleString()}</p><h2>Top signals</h2><ol>${snapshot.trending.slice(0,5).map((t)=>`<li><b>${t.topic}</b> — ${t.mentions.toLocaleString()} mentions, ${Math.round(t.velocity)}% velocity, sentiment ${t.sentiment.toFixed(2)}</li>`).join("")}</ol><h2>Emerging stories</h2><ul>${snapshot.emerging.slice(0,5).map((s)=>`<li>${s.headline} (${s.anomalyScore}/99 anomaly)</li>`).join("")}</ul><p>Use the browser’s Save as PDF option to archive this report.</p>`;
    const report = window.open("", "_blank"); report.document.write(`<title>PULSE intelligence report</title><style>body{font:15px Arial;max-width:760px;margin:48px auto;color:#142033}h1{color:#0a766a}li{margin:10px 0}</style>${body}`); report.document.close(); report.print();
  }
  async function toggleWatch(topic) {
    const existing = alerts.find((alert) => alert.topic === topic);
    if (existing) { await deleteAlert(existing.id); setAlerts((old) => old.filter((alert) => alert.id !== existing.id)); }
    else { const created = await createAlert(topic); setAlerts((old) => [...old, created]); }
    setWatchlist((old) => old.includes(topic) ? old.filter((x) => x !== topic) : [...old, topic]);
  }
  function signIn() { const name = window.prompt("Enter analyst name"); if (name?.trim()) { localStorage.setItem("pulse-user", name.trim()); setUser(name.trim()); } }

  return (
    <div className="min-h-screen bg-ink font-body">
      <Header connected={connected} generatedAt={snapshot?.generatedAt} totalMentions={snapshot?.totalMentions} user={user} onSignIn={signIn} onSignOut={()=>{localStorage.removeItem("pulse-user");setUser("")}} />
      {snapshot && <Ticker stories={snapshot.emerging} onSelect={setSelectedStory} />}

      <main className="max-w-7xl mx-auto px-6 py-6">
        {error && !snapshot && (
          <div className="bg-panel border border-alert/40 text-alert rounded-xl p-4 text-sm mb-6">
            Couldn't reach the backend at the configured API URL. Start the backend
            (<code className="font-mono">cd backend && npm run dev</code>) and refresh. ({error})
          </div>
        )}

        {toast && <div className="fixed right-6 bottom-6 z-30 rounded-lg border border-pulse/30 bg-panel px-4 py-3 text-sm text-fog shadow-2xl">✓ {toast}</div>}
        {!snapshot ? (
          <LoadingState />
        ) : selectedStory ? (
          <StoryDetail story={selectedStory} onBack={() => setSelectedStory(null)} />
        ) : selectedTopic ? (
          <TopicDetail topic={selectedTopic} history={snapshot.history} onBack={() => setSelectedTopic(null)} />
        ) : (
          <>
            <CommandBar query={query} setQuery={setQuery} sourceType={sourceType} setSourceType={setSourceType} onExport={exportBrief} onReport={exportReport} searching={searching} resultCount={filteredSearchResults.length} />
            <IntelligenceBar snapshot={snapshot} watchlist={watchlist} alerts={alerts} onWatch={toggleWatch} />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className="lg:col-span-2">
              {searchActive
                ? <SearchResults query={query} results={filteredSearchResults} searching={searching} onSelect={setSelectedStory} />
                : <TrendingTopics topics={filteredTopics} watchlist={watchlist} onWatch={toggleWatch} onSelect={setSelectedTopic} />}
            </div>
            <SentimentChart avgSentiment={snapshot.avgSentiment} buckets={snapshot.sentimentBuckets} />

            <div className="lg:col-span-3">
              <EmergingStories stories={filteredStories} onSelect={setSelectedStory} />
            </div>

            <div className="lg:col-span-3">
              <SourceFrequency sources={snapshot.sources} />
            </div>

            <div className="lg:col-span-2"><GeoMap geo={snapshot.geo} selected={selectedCountry} onSelect={setSelectedCountry} /></div>
            <div><GeoDistribution geo={selectedCountry ? snapshot.geo.filter((g)=>g.code===selectedCountry) : snapshot.geo} /></div>
            <div className="lg:col-span-3"><ActivityTimeline history={snapshot.history} /></div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

function CommandBar({ query, setQuery, sourceType, setSourceType, onExport, onReport, searching, resultCount }) {
  return <section className="mb-5 rounded-xl border border-line bg-panel p-3 flex flex-col gap-3 md:flex-row md:items-center">
    <div className="relative flex-1"><span className="absolute left-3 top-2.5 text-muted">⌕</span><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search the live web: Tesla, elections, cricket…" className="w-full rounded-lg border border-line bg-ink py-2 pl-9 pr-24 text-sm text-fog outline-none focus:border-signal" />{query.trim().length >= 2 && <span className="absolute right-3 top-2.5 text-[10px] font-mono text-pulse">{searching ? "SEARCHING…" : `${resultCount} LIVE RESULTS`}</span>}</div>
    <select value={sourceType} onChange={(e) => setSourceType(e.target.value)} className="rounded-lg border border-line bg-ink px-3 py-2 text-sm text-fog outline-none"><option value="all">All channels</option><option value="social">Social media</option><option value="wire">News wires</option><option value="broadcast">Broadcast</option><option value="blog">Blogs</option></select>
    <button onClick={onExport} className="rounded-lg bg-signal px-4 py-2 text-sm font-semibold text-ink hover:brightness-110">Export brief ↓</button>
    <button onClick={onReport} className="rounded-lg border border-pulse/40 px-4 py-2 text-sm text-pulse hover:bg-pulse/10">Print report</button>
  </section>;
}

function Header({ connected, generatedAt, totalMentions, user, onSignIn, onSignOut }) {
  return (
    <header className="border-b border-line bg-ink/95 backdrop-blur sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-signal/10 border border-signal/30 flex items-center justify-center">
            <span className="w-2 h-2 rounded-full bg-signal live-dot" />
          </div>
          <div>
            <h1 className="font-display text-lg font-semibold text-fog tracking-tight">PULSE</h1>
            <p className="text-[11px] text-muted -mt-0.5">AI News Intelligence Dashboard</p>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs font-mono text-muted">
          {typeof totalMentions === "number" && (
            <span>
              <span className="text-fog">{totalMentions.toLocaleString()}</span> mentions tracked
            </span>
          )}
          {generatedAt && <span>updated {new Date(generatedAt).toLocaleTimeString()}</span>}
          <span className={`flex items-center gap-1.5 ${connected ? "text-pulse" : "text-alert"}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${connected ? "bg-pulse" : "bg-alert"}`} />
            {connected ? "LIVE" : "CONNECTING"}
          </span>
          <button onClick={user ? onSignOut : onSignIn} className="rounded border border-line px-2 py-1 text-[10px] text-fog hover:border-signal">{user ? `${user} · sign out` : "Analyst sign in"}</button>
        </div>
      </div>
    </header>
  );
}

function Ticker({ stories, onSelect }) {
  const items = stories.length ? stories : [{ id: "placeholder", headline: "Monitoring global sources…" }];
  const doubled = [...items, ...items];

  return (
    <div className="bg-panel2 border-b border-line overflow-hidden">
      <div className="flex items-center">
        <div className="shrink-0 bg-signal text-ink text-[11px] font-mono font-semibold px-3 py-2 uppercase tracking-wide">
          Breaking
        </div>
        <div className="flex-1 overflow-hidden py-2">
          <div className="ticker-track flex whitespace-nowrap w-max">
            {doubled.map((s, i) => {
              const clickable = s.id !== "placeholder" && s.countries;
              return (
                <span
                  key={`${s.id}-${i}`}
                  onClick={clickable ? () => onSelect?.(s) : undefined}
                  className={`text-xs text-fog px-6 border-r border-line ${
                    clickable ? "cursor-pointer hover:text-signal transition-colors" : ""
                  }`}
                  title={clickable ? "Click for full breakdown" : undefined}
                >
                  {s.headline}
                </span>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="bg-panel border border-line rounded-xl p-5 h-48 animate-pulse" />
      ))}
    </div>
  );
}
