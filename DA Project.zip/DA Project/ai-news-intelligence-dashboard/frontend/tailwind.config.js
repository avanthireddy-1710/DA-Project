/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0B0E14",       // page background
        panel: "#121722",     // card background
        panel2: "#171E2C",    // raised/hover panel
        line: "#232B3A",      // hairlines / borders
        signal: "#FFB020",    // amber - "breaking / live" accent
        pulse: "#3FD8C2",     // teal - positive / active accent
        alert: "#FF6B6B",     // coral - negative / alert accent
        muted: "#7C8798",     // secondary text
        fog: "#C4CCDA",       // primary text on dark
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
