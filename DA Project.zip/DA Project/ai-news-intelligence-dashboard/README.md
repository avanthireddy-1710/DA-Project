# PULSE — AI News Intelligence Dashboard (Demo)

A full-stack, real-time social and news intelligence platform. PULSE turns a
stream of cross-platform news signals into an analyst-ready dashboard for
discovering what is trending, where it is trending, how audiences feel, and
which stories are beginning to accelerate.

This is a **live public-data prototype**: the backend fetches current stories
from Google News RSS, Hacker News, and Reddit, aggregates them, and broadcasts
the results to connected dashboards. Public sources may occasionally rate-limit
or be unavailable; the dashboard reports partial-feed status rather than
inventing data.

## Intelligence capabilities

- **Live global monitoring** — REST bootstrap plus Socket.io updates every five seconds.
- **Cross-channel coverage** — wire services, social platforms, broadcast outlets, blogs, and technical communities.
- **Trend ranking** — topic mention volume, share of conversation, velocity, and directional sentiment.
- **AI sentiment intelligence** — positive / neutral / negative distribution and an overall net-sentiment score.
- **Emerging-story detection** — high-velocity breaking stories, a live ticker, relative source / country context, and instant drill-down.
- **Story deep-dive** — country-by-country audience reaction, like/dislike split, virality probability, source coverage, related stories, and a global reaction indicator.
- **Geographic intelligence** — regional mention distribution for global impact analysis.
- **Analyst workflow tools** — global search, source-category filtering, topic watchlist, an alert-style overview, downloadable CSV intelligence briefs, and an activity timeline with anomaly-status indicator.
- **Resilient presentation** — loading state, connection state, API error state, responsive panels, accessible labels, and reduced-motion support.
- **Executive output** — printable daily intelligence reports that use the browser's Save as PDF flow.
- **Analyst experience** — persisted browser identity, topic deep-dives, a click-to-filter signal map, alert rules, and source-quality scoring.

## Intelligence pipeline

Each incoming story is processed through an extensible analytics layer before
it is sent to the dashboard. The prototype includes dependency-free keyword
and entity extraction, a risk classifier, source-quality scoring, generated
story briefs, and an anomaly score composed from velocity, virality, and
sentiment strength. Aggregate snapshots are persisted to
`backend/data/intelligence-history.json`, which makes the historical timeline
survive a server restart.

The alert API supports analyst-created velocity thresholds:

```text
GET    /api/news/alerts
POST   /api/news/alerts     { "topic": "AI Regulation", "threshold": 50 }
DELETE /api/news/alerts/:id
```

For production, replace the simulated producer in `newsService.js` with
connector jobs (RSS, Reddit, GDELT, or approved commercial APIs). API keys
must be kept in environment variables, never in the repository.

`backend/connectors/rssConnector.js` is a ready optional RSS adapter. Set
`RSS_FEEDS` to trusted feed URLs and invoke it from an ingestion job. Social
network and commercial-news connectors should follow the same normalized item
shape, with their API keys held in environment variables.

## Folder structure

```
ai-news-intelligence-dashboard/
├── backend/
│   ├── data/
│   │   └── mockNews.js        # seed data: topics, sources, countries, headline templates
│   ├── routes/
│   │   └── news.js            # REST endpoints (/api/news/*)
│   ├── services/
│   │   └── newsService.js     # in-memory state + aggregation logic, "tick()" simulates live updates
│   ├── server.js               # Express app + Socket.io server
│   └── package.json
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── api/
│   │   │   └── newsApi.js     # REST fetch + socket.io client
│   │   ├── components/
│   │   │   ├── TrendingTopics.jsx
│   │   │   ├── SentimentChart.jsx
│   │   │   ├── GeoDistribution.jsx
│   │   │   ├── SourceFrequency.jsx
│   │   │   └── EmergingStories.jsx
│   │   │   ├── IntelligenceBar.jsx  # KPI overview + watchlist
│   │   │   └── ActivityTimeline.jsx # monitoring-window visualization
│   │   ├── App.jsx             # layout, header, ticker, live connection state
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── vite.config.js
│   └── package.json
│
└── README.md
```

## How it works

- **Backend** (`backend/`): Express serves REST endpoints under `/api/news/*`
  for a first-load snapshot, and a Socket.io server broadcasts a fresh
  `snapshot` event every 5 seconds so connected dashboards update live
  without polling.
- **Frontend** (`frontend/`): a Vite + React app. On mount it fetches the
  initial snapshot over REST, then subscribes to the socket for live updates.
  It provides an analyst dashboard, filtering/search controls, local alert
  watchlist, exported brief, and clickable story detail views.

## Run it locally

**1. Backend**

```bash
cd backend
npm install
npm run dev        # or: npm start
# → http://localhost:4000
```

**2. Frontend** (in a second terminal)

```bash
cd frontend
npm install
npm run dev
# → http://localhost:5173
```

Open `http://localhost:5173`. The dashboard connects to the backend at
`http://localhost:4000` by default — override with a `.env` file in
`frontend/` containing `VITE_API_BASE=http://your-backend-host:4000`.

## Where to plug in real data

Replace the contents of `backend/services/newsService.js` (and drop
`backend/data/mockNews.js`) with real connectors, for example:
- News APIs: NewsAPI, GDELT, Bing News Search
- Social: X/Twitter API, Reddit API, Mastodon
- Sentiment: a hosted NLP API or a local model (e.g. VADER, a HF pipeline)
- Geo: resolve mentions to countries via NER + a geocoding service

As long as `getSnapshot()` keeps returning the same shape
(`trending`, `sentimentBuckets`, `avgSentiment`, `sources`, `geo`,
`emerging`), the frontend doesn't need to change.

## Production roadmap

- Persist snapshots (Postgres/Timescale or Redis) instead of in-memory state
- Add auth + rate limiting on the API
- Replace the country list with a proper world map (e.g. `react-simple-maps`)
- Persist historical time series and generate the timeline from stored events
- Add authenticated alert delivery (email/webhook/Slack) when velocity crosses a threshold
- Add source credibility scoring, duplicate-story clustering, multilingual NLP, and role-based access control
